export interface MContext {
    appname?: string;
    version?: number;
}