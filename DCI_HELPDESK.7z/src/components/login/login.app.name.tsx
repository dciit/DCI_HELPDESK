import React from 'react'

function LoginAppName() {
    return (
        <div>
            <span>IT HELPDESK</span>
        </div>
    )
}

export default LoginAppName