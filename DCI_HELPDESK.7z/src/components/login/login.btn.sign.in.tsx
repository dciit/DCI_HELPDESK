import React from 'react'
import { Button } from '../ui/button'

function LoginBtnSignIn() {
    return (
        <Button>เข้าสู่ระบบ</Button>
    )
}

export default LoginBtnSignIn