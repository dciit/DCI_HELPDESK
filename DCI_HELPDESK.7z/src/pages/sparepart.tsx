import React from 'react'

function Sparepart() {
    return (
        <div>Sparepart</div>
    )
}

export default Sparepart